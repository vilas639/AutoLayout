//
//  ViewController.swift
//  Dicee-iOS13
//
//  Created by Angela Yu on 11/06/2019.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //call refernce
    @IBOutlet weak var diceOne: UIImageView!
    @IBOutlet weak var diceTwo: UIImageView!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //who.what = value
        diceOne.image = #imageLiteral(resourceName: "DiceFour")
      //  diceOne.alpha = 0.5;
        
        diceTwo.image = #imageLiteral(resourceName: "DiceFive")
        
    }

    @IBAction func btnRoll(_ sender: UIButton) {
        
        print("you just tapped")
        
        let dice = [#imageLiteral(resourceName: "DiceOne"),#imageLiteral(resourceName: "DiceTwo"),#imageLiteral(resourceName: "DiceThree"),#imageLiteral(resourceName: "DiceFour"),#imageLiteral(resourceName: "DiceFive"),#imageLiteral(resourceName: "DiceSix")]
        
        diceOne.image = dice.randomElement();
            //  diceOne.alpha = 0.5;
              
        diceTwo.image = dice.randomElement();
    }
    
}

