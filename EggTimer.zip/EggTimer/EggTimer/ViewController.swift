//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {
    
   var player: AVAudioPlayer?
    @IBOutlet weak var txtlable: UILabel!
     @IBOutlet weak var progressBar: UIProgressView!
    
    let eggsTimes = ["Soft":3, "Medium":4, "Hard": 7]
    
    var count = 60
    
    var timer = Timer()
    var isRed = false
    var progressBarTimer: Timer!
    var isRunning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        progressBar.progress = 0.0
    }

    @IBAction func btneggs(_ sender: Any) {
        progressBar.progress = 0.0
        timer.invalidate()
        
        let hardness = (sender as AnyObject).currentTitle!
       
         count = eggsTimes[hardness!]!
              
        
         timer = Timer.scheduledTimer(timeInterval: 0.4, target: self, selector: #selector(update), userInfo: nil, repeats: true)

          
        if(isRunning){
            progressBarTimer.invalidate()
            txtlable.text = "Start"
            //btn.setTitle("Start", for: .normal)
        }
        else{
        txtlable.text = "Stop"
        progressBar.progress = 0.0
        self.progressBarTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(update), userInfo: nil, repeats: true)
        if(isRed){
            progressBar.progressTintColor = UIColor.blue
            progressBar.progressViewStyle = .default
        }
        else{
            progressBar.progressTintColor = UIColor.red
            progressBar.progressViewStyle = .bar
            
        }
        isRed = !isRed
        }
        isRunning = !isRunning

        
        
        
       
    }
    
    
    
   
    
    @objc func update() {
    if(count > 0) {
        //countDownLabel.text = String(count--)
        
        progressBar.progress += 0.1
        progressBar.setProgress(progressBar.progress, animated: true)
        if(progressBar.progress == 1.0)
        {
            progressBarTimer.invalidate()
            isRunning = false
           txtlable.text = "Start"
        }
        print("\(count) in seconds.")
        count -= 1;
    }
        else
    {
        timer.invalidate()
        txtlable.text = "Done !"
        playSound()
        }
    }
    
    
    func playSound() {
        
        let url = Bundle.main.url(forResource: "alarm_sound", withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        player?.play()
    }
}
